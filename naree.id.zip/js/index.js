  function sideBar(task){
    if(task === 'close'){
      $('.side-bar').css({"width":"5%"});
      $('.row-side').css({"font-size":".5rem","padding":"0"});
      $('.icon-side').attr({"class":"col-12 icon-side text-center"});
      $('.text-side').attr({"class":"col-12 text-side text-center"});
      $('.text-side').css({"margin-top":"-15px"});
      $('.icon-side').css({"min-height":"45px"});
      $('#hamburger').attr({"onclick":"sideBar(`open`)"});
      $('#content').css({"width":"95%","left":"5%"});
    }else{
      $('.side-bar').css({"width":"20%"});
      $('.row-side').css({"font-size":".9rem","padding":"10px 0"});
      $('.icon-side').attr({"class":"col-3 icon-side"});
      $('.text-side').attr({"class":"col-9 text-side"});
      $('.text-side').css({"margin-top":"auto"});
      $('.icon-side').css({"min-height":"40px"});
      $('#hamburger').attr({"onclick":"sideBar(`close`)"});
      $('#content').css({"width":"80%","left":"20%"});
    }
  }

function hashPage(page){
  location.hash = page;
}

function switchPage(page){
      dotLight('content');
      $('.row-side').removeClass('side-active invert');
      $('.row-side').addClass('side-inactive');

      $('#'+page).removeClass('side-inactive');
      $('#'+page).addClass('side-active');

      $('.icon-image').addClass('invert');
      $('#image-home').attr({"src":"icon/home.svg"});
      $('#image-news').attr({"src":"icon/News.svg"});
      $('#image-promotion').attr({"src":"icon/promotion.svg"});
      $('#image-event').attr({"src":"icon/event.svg"});
      $('#image-rank').attr({"src":"icon/rank.svg"});
      $('#image-profile').attr({"src":"icon/profile.png"});

if(page !== 'profile'){
  $('#image-'+page).attr({"src":"icon/"+page+"-active.svg"});
  $('#image-'+page).removeClass('invert');
}else{
  $('#image-'+page).attr({"src":"icon/"+page+"-active.png"});
  $('#image-'+page).removeClass('invert');
}

      setTimeout(function(){
        $.ajax({
          url: "template/"+page+".php",
          method : "POST",
          success: function(result){
                 $('#content').html(result);
          }});
      },1000)
  }

window.onhashchange = function(){
  var p = location.hash;
  var pages = p.replace('#','');
  if(pages === ''){
    pages = 'home';
  }

  switchPage(pages);
};


setTimeout(function(){switchBannerAuto()},10000);
var i = 0;
function switchBannerAuto(){
newi = i + 1;
if (i < 4) {
  $(".image-banner:eq("+i+")").attr({"class":"image-banner image-banner-inactive abs-center"});
  $(".image-banner:eq("+newi+")").attr({"class":"image-banner image-banner-active abs-center"});
  $(".dot-banner-circle:eq("+i+")").attr({"class":"dot-banner-circle dot-banner-inactive"});
  $(".dot-banner-circle:eq("+newi+")").attr({"class":"dot-banner-circle dot-banner-active"});
  i++;
  setTimeout(function(){switchBannerAuto();},10000);
}else{
  $(".image-banner:eq(4)").attr({"class":"image-banner image-banner-inactive abs-center"});
  $(".image-banner:eq(0)").attr({"class":"image-banner image-banner-active abs-center"});
  $(".dot-banner-circle:eq(4)").attr({"class":"dot-banner-circle dot-banner-inactive"});
  $(".dot-banner-circle:eq(0)").attr({"class":"dot-banner-circle dot-banner-active"});
  i = 0;
  setTimeout(function(){switchBannerAuto();},10000);
}
}
