<div class="nav">
  <div class="top-bar">
    <img id="logo-utama" src="icon/logo-1.png">

    <button id="hamburger" onclick="sideBar('close')" >
      <img src="icon/menu.svg?<?= time();?>" class="abs-center">
    </button>

    <div id="top-side-nav">
        <button>
          <img src="icon/more.svg" class="invert">
        </button>
        <button>
          <img src="icon/heart-active.svg" class="invert">
        </button>
        <button>
          <img src="icon/bell.svg" class="invert">
        </button>
        <div id="profile-icon">

        </div>
    </div>
  </div>
  <div class="side-bar">
      <div class="container-fluid">
        <div class="row row-side side-active" id="home" onclick="hashPage('home')">
            <div class="col-3 icon-side">
                <img id="image-home" src="icon/home-active.svg" class="icon-image rel-center">
            </div>
            <div class="col-9 text-side">
                <span>Home</span>
            </div>
        </div>
        <div class="row row-side side-inactive" id="news" onclick="hashPage('news')">
            <div class="col-3 icon-side">
                <img id="image-news" src="icon/news.svg" class="icon-image rel-center invert">
            </div>
            <div class="col-9 text-side">
                <span>News</span>
            </div>
        </div>
        <div class="row row-side side-inactive" id="promotion" onclick="hashPage('promotion')">
            <div class="col-3 icon-side">
                <img id="image-promotion" src="icon/promotion.svg" class="icon-image rel-center invert">
            </div>
            <div class="col-9 text-side">
                <span>Promotion</span>
            </div>
        </div>
        <div class="row row-side side-inactive" id="event" onclick="hashPage('event')">
            <div class="col-3 icon-side">
                <img id="image-event" src="icon/event.svg" class="icon-image rel-center invert">
            </div>
            <div class="col-9 text-side">
                <span>Event</span>
            </div>
        </div>
        <div class="row row-side side-inactive" id="rank" onclick="hashPage('rank')">
            <div class="col-3 icon-side">
                <img id="image-rank" src="icon/rank.svg" class="icon-image rel-center invert">
            </div>
            <div class="col-9 text-side">
                <span>Ranking</span>
            </div>
        </div>
        <div class="row row-side side-inactive" id="profile" onclick="hashPage('profile')">
            <div class="col-3 icon-side">
                <img id="image-profile" src="icon/profile.png" class="icon-image rel-center invert">
            </div>
            <div class="col-9 text-side">
                <span>Profile</span>
            </div>
        </div>
      </div>
  </div>
</div>


<script>
  setTimeout(function(){
    var hashNow = location.hash;
    if(hashNow === ''){
      location.hash = 'home';
      switchPage('home');
    }else if(hashNow === '#home'){
      switchPage('home');
    }else if(hashNow === '#news'){
      switchPage('news');
    }else if(hashNow === '#promoion'){
      switchPage('promotion');
    }else if(hashNow === '#event'){
      switchPage('event');
    }else if(hashNow === '#rank'){
      switchPage('rank');
    }else if(hashNow === '#profile'){
      switchPage('profile');
    }
  },300);
</script>
