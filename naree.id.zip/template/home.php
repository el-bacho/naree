<div id="banner">
  <img class="image-banner image-banner-active abs-center" src="https://picsum.photos/id/123/900/600?random=5">
  <img class="image-banner image-banner-inactive abs-center" src="https://picsum.photos/id/126/900/600?random=5">
  <img class="image-banner image-banner-inactive abs-center" src="https://picsum.photos/id/125/900/600?random=5">
  <img class="image-banner image-banner-inactive abs-center" src="https://picsum.photos/id/365/900/600?random=5">
  <img class="image-banner image-banner-inactive abs-center" src="https://picsum.photos/id/653/900/600?random=5">

  <div class="dot-banner">
      <div class="dot-banner-circle dot-banner-active"></div>
      <div class="dot-banner-circle dot-banner-inactive"></div>
      <div class="dot-banner-circle dot-banner-inactive"></div>
      <div class="dot-banner-circle dot-banner-inactive"></div>
      <div class="dot-banner-circle dot-banner-inactive"></div>
  </div>
</div>
<div class="row-card">
      <div class="judul-row-card">Berita Terbaru</div>
      <div class="container-fluid" style="padding:10px 10px;margin-top:10px;">
        <div class="row" style="padding:0">
<?php for ($x = 0; $x <= 3; $x++){?>
          <div class="col-3" style="padding:0">
              <div class="st-card">
                <div class="image-st-card">

                  <div class="action-card">
                    <div class="but-action-card">
                      <img src="icon/heart.svg" class="abs-center" style="width:50%">
                    </div>
                    <div class="but-action-card">
                      <img src="icon/share.svg" class="abs-center" style="width:50%">
                    </div>
                  </div>
                </div>
                <div class="text-card">
                    <div class="tanggal-card">26 Feb 2020</div>
                    <div class="judul-card">Lorem Ipsum has been the industry's standard dummy text..</div>
                    <div class="penulis-card">Prof.Dadang Konelo</div>
                </div>
              </div>
          </div>
<?php };?>
        </div>
      </div>
      <div align="center" style="padding:15px 0">
        <button class="but-md but-dark">
          See More
        </button>
      </div>
</div>
