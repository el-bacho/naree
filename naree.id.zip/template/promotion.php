<div style="width:100%;height:700px;">
  <h1 class="abs-center">Promotion</h1>
</div>
