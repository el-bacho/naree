<?php require 'template/top.php';?>


<title>Naree - Home</title>
</head>
<body>
<?php require 'template/nav.php';?>

<div id="content">

</div>


<?php require 'template/bottom.php';?>
