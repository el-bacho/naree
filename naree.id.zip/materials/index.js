function dotLight(id){
  $('#'+id).html('<div class="dot-light"><div class="dot-light-1 dot-1"></div><div class="dot-light-2 dot-2"></div><div class="dot-light-3 dot-3"></div><div class="dot-light-4 dot-4"></div><div class="dot-light-5 dot-5"></div></div>');
}
