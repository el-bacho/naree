<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="index.css">

    <title>Naree Material Design</title>
  </head>
  <body style="background-color:grey;width:100%;height:100%">
    <div style="padding:30px 15px;background-color:white;width:100%;max-width:600px;position:relative;left:50%;transform:translate(-50%)">
        <div align="center">
            <h3>Naree Material Content</h3>
        </div>
        <br>
        <div>

            <div style="font-size:1.1rem;font-weight:bold" align="center">
            Loading Event
            </div>
            <div style="display:flex;padding:10px 10px 0 10px;min-height:150px;margin-top:20px">
                <div style="width:50%;position:relative;border:1px solid #96161A">
                    <div class="loading-light">
                        <img class="logo-1" src="logo-loading/light-1.png" style="width:100%">
						<img class="logo-2" src="logo-loading/light-2.png" style="width:100%">
						<img class="logo-3" src="logo-loading/light-3.png" style="width:100%">
                    </div>
                </div>
				<div style="width:50%;position:relative;background-color:#96161A">
                    <div class="loading-dark">
                        <img class="logo-1" src="logo-loading/dark-1.png" style="width:100%">
						<img class="logo-2" src="logo-loading/dark-2.png" style="width:100%">
						<img class="logo-3" src="logo-loading/dark-3.png" style="width:100%">
                    </div>
                </div>
            </div>
			<div style="display:flex;padding:0 10px 10px 10px;min-height:150px;margin-top:20px">
                <div style="width:50%;position:relative;background-color:#96161A">
                    <div class="dot-dark">
                        <div class="dot-dark-1 dot-1"></div>
            						<div class="dot-dark-2 dot-2"></div>
            						<div class="dot-dark-3 dot-3"></div>
            						<div class="dot-dark-4 dot-4"></div>
            						<div class="dot-dark-5 dot-5"></div>
                    </div>
                </div>
				<div style="width:50%;position:relative;border:1px solid #96161A">
                    <div class="dot-light">
                        <div class="dot-light-1 dot-1"></div>
            						<div class="dot-light-2 dot-2"></div>
            						<div class="dot-light-3 dot-3"></div>
            						<div class="dot-light-4 dot-4"></div>
            						<div class="dot-light-5 dot-5"></div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>
